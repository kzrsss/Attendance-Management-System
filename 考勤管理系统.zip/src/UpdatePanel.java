import javax.swing.*;

import dao.DatabaseHelper;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UpdatePanel extends JPanel {
    private JTextField studentNameField;
    private JTextField studentIDField;
    private JTextField dateField;
    private JTextField lessonField;
    private JTextField courseField;
    private JComboBox<String> absenceTypeComboBox;
    private JButton submitButton;
    private JButton clearButton;

    public UpdatePanel() {
        setLayout(new GridLayout(0, 2));

        JLabel studentName = new JLabel("ѧ������:");
        add(studentName);
        studentName.setHorizontalAlignment(SwingConstants.CENTER);
        studentNameField = new JTextField();
        add(studentNameField);

        JLabel studentId = new JLabel("ѧ��ѧ��:");
        add(studentId);
        studentId.setHorizontalAlignment(SwingConstants.CENTER);
        studentIDField = new JTextField();
        add(studentIDField);

        JLabel date = new JLabel("��������:");
        add(date);
        date.setHorizontalAlignment(SwingConstants.CENTER);
        dateField = new JTextField();
        add(dateField);

        JLabel lesson = new JLabel("���ڿ�ʱ:");
        add(lesson);
        lesson.setHorizontalAlignment(SwingConstants.CENTER);
        lessonField = new JTextField();
        add(lessonField);

        JLabel subject = new JLabel("���ڿ�Ŀ:");
        add(subject);
        subject.setHorizontalAlignment(SwingConstants.CENTER);
        courseField = new JTextField();
        add(courseField);

        JLabel type = new JLabel("��������:");
        add(type);
        type.setHorizontalAlignment(SwingConstants.CENTER);
        String[] Types = {"�ٵ�", "����", "����", "ȱϯ"};
        absenceTypeComboBox = new JComboBox<>(Types);
        add(absenceTypeComboBox);

        submitButton = new JButton("�޸�");
        add(submitButton);

        clearButton = new JButton("���");
        add(clearButton);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // ��ȡ������Ϣ
                String studentName = studentNameField.getText();
                String studentID = studentIDField.getText();
                String date = dateField.getText();
                String lesson = lessonField.getText();
                String course = courseField.getText();
                String absenceType = (String) absenceTypeComboBox.getSelectedItem();

                // У������
                if (studentName.isEmpty() || studentID.isEmpty() || date.isEmpty() || lesson.isEmpty() || course.isEmpty() || absenceType.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "�����ֶζ��Ǳ����");
                    return;
                }
                saveToDatabase(studentName, studentID, date, lesson, course, absenceType);
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // ��������
                studentNameField.setText("");
                studentIDField.setText("");
                dateField.setText("");
                lessonField.setText("");
                courseField.setText("");
            }
        });
    }

    private void saveToDatabase(String studentName, String studentID, String date, String lesson, String course, String absenceType) {
        // ���������ӽ����ݱ��浽���ݿ�Ĵ���
        // ����ʹ�� JDBC �������ݿⲢִ����Ӧ�� SQL ���
        DatabaseHelper databaseHelper = new DatabaseHelper();
        boolean success = databaseHelper.updateDatabase(studentName, studentID, date, lesson, course, absenceType);
        if (success) {
            JOptionPane.showMessageDialog(this, "�������ݳɹ�");
        } else {
            JOptionPane.showMessageDialog(this, "���޴��˻��������ʧ��");
        }
    }
}