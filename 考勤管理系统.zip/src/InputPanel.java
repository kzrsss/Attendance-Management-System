import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.DatabaseHelper;

public class InputPanel extends JPanel {
	private JTextField studentNameField;
	private JTextField studentIDField;
	private JTextField dateField;
	private JTextField lessonField;
	private JTextField courseField;
	private JComboBox<String> absenceTypeComboBox;
	private JButton submitButton;
	private JButton clearButton;

	public InputPanel() {
		this.setLayout(new GridLayout(0, 2));
		JLabel studentName = new JLabel("ѧ������:");
		this.add(studentName);
		studentName.setHorizontalAlignment(0);
		this.studentNameField = new JTextField();
		this.add(this.studentNameField);
		JLabel studentId = new JLabel("ѧ��ѧ��:");
		this.add(studentId);
		studentId.setHorizontalAlignment(0);
		this.studentIDField = new JTextField();
		this.add(this.studentIDField);
		JLabel date = new JLabel("��������:");
		this.add(date);
		date.setHorizontalAlignment(0);
		this.dateField = new JTextField();
		this.add(this.dateField);
		JLabel lesson = new JLabel("���ڿ�ʱ:");
		this.add(lesson);
		lesson.setHorizontalAlignment(0);
		this.lessonField = new JTextField();
		this.add(this.lessonField);
		JLabel subject = new JLabel("���ڿ�Ŀ:");
		this.add(subject);
		subject.setHorizontalAlignment(0);
		this.courseField = new JTextField();
		this.add(this.courseField);
		JLabel type = new JLabel("��������:");
		this.add(type);
		type.setHorizontalAlignment(0);
		String[] Types = new String[] { "�ٵ�", "����", "����", "ȱϯ" };
		this.absenceTypeComboBox = new JComboBox(Types);
		this.add(this.absenceTypeComboBox);
		this.submitButton = new JButton("¼��");
		this.add(this.submitButton);
		this.clearButton = new JButton("���");
		this.add(this.clearButton);
		this.submitButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String studentName = InputPanel.this.studentNameField.getText();
		        String studentID = InputPanel.this.studentIDField.getText();
		        String date = InputPanel.this.dateField.getText();
		        String lesson = InputPanel.this.lessonField.getText();
		        String course = InputPanel.this.courseField.getText();
		        String absenceType = (String) InputPanel.this.absenceTypeComboBox.getSelectedItem();
		        if (studentName.isEmpty() || studentID.isEmpty() || date.isEmpty() || lesson.isEmpty()
		                || course.isEmpty()) {
		            JOptionPane.showMessageDialog(null, "�����ֶζ��Ǳ���ģ�����д����");
		            return;
		        }

		        if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
		            JOptionPane.showMessageDialog(null, "���ڸ�ʽӦΪ YYYY-MM-DD");
		            return;
		        }
		        // ���� saveToDatabase ����������������ֱ����ʾ�ɹ�
		        InputPanel.this.saveToDatabase(studentName, studentID, date, lesson, course, absenceType);
		        // �ɹ���ʾ������ saveToDatabase �����д���
		    }
		});
		this.clearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InputPanel.this.studentNameField.setText("");
				InputPanel.this.studentIDField.setText("");
				InputPanel.this.dateField.setText("");
				InputPanel.this.lessonField.setText("");
				InputPanel.this.courseField.setText("");
			}
		});
	}

	private void saveToDatabase(String studentName, String studentID, String date, String lesson, String course,
			String absenceType) {

		DatabaseHelper.saveToDatabase(studentName, studentID, date, lesson, course, absenceType);
	}
}