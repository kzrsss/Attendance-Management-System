package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
 
public class DatabaseHelper {
    // JDBC����URL���û���������
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/student?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "kzr13883288366";
 
    public static Object[][] performDatabaseQuery(String selectedSubject, String selectedAbsenceType, String startDate) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Object[]> dataList = new ArrayList<>();
 
        try {
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
 
            String sql = "SELECT student_name, type, date FROM attendance_records " +
                    "WHERE course = ? AND type = ? AND date = ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, selectedSubject);
            statement.setString(2, selectedAbsenceType);
            statement.setString(3, startDate);
       
 
            resultSet = statement.executeQuery();
 
            while (resultSet.next()) {
                String studentName = resultSet.getString("student_name");
                String Type = resultSet.getString("type");
                String absenceDate = resultSet.getString("date");
 
                Object[] row = { studentName, Type, absenceDate };
                dataList.add(row);
            }
 
        } catch (SQLException ex) {
            ex.printStackTrace();
            // ���Ը�����Ҫ�����쳣
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
 
        // ת��Ϊ Object[][] ����
        Object[][] data = new Object[dataList.size()][3];
        for (int i = 0; i < dataList.size(); i++) {
            data[i] = dataList.get(i);
        }
        return data;
    }
 
    public static String[] getSubjects() {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
 
        String[] result = new String[20];
 
        try {
            // �������ݿ�����
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            // ����SQL���
            String sql = "SELECT DISTINCT course FROM attendance_records";
            statement = connection.prepareStatement(sql);
 
            // ִ�в�ѯ
            resultSet = statement.executeQuery();
 
            // ������ѯ���
            int i = 0;
            while (resultSet.next() && i < result.length) {
                result[i++] = resultSet.getString(1);
            }
 
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            // �ر�ResultSet��Statement��Connection
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }
 
    public static String[] getTimes() {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
 
        String[] result = new String[200];
 
        try {
            // �������ݿ�����
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
 
            // ����SQL���
            String sql = "SELECT DISTINCT date FROM attendance_records";
            statement = connection.prepareStatement(sql);
 
            // ִ�в�ѯ
            resultSet = statement.executeQuery();
 
            // ������ѯ���
            int i = 0;
            while (resultSet.next() && i < result.length) {
                result[i++] = resultSet.getString(1);
            }
 
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            // �ر�ResultSet��Statement��Connection
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }
 
 
    public static void saveToDatabase(String studentName, String studentID, String date, String lesson, String course, String absenceType) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // �������ݿ�����
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

            // ������֤������ѧ���Ƿ�ƥ��
            String checkSql = "SELECT * FROM student_users WHERE id = ? AND name = ?";
            statement = connection.prepareStatement(checkSql);
            statement.setString(1, studentID);
            statement.setString(2, studentName);
            resultSet = statement.executeQuery();

            if (!resultSet.next()) {
                // �����ƥ�䣬��ʾ�û�������
                JOptionPane.showMessageDialog(null, "������ѧ�Ų�ƥ�䣬������¼��");
                return;
            }

            // ���ƥ�䣬����SQL�����뿼�ڼ�¼
            String sql = "INSERT INTO attendance_records (student_name, student_id, date, lesson, course, type) VALUES (?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(sql);

            // ����SQL������
            statement.setString(1, studentName);
            statement.setString(2, studentID);
            statement.setString(3, date);
            statement.setString(4, lesson);
            statement.setString(5, course);
            statement.setString(6, absenceType);

            // ִ��SQL���
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                // �������ɹ�����ʾ�û�
                JOptionPane.showMessageDialog(null, "���ڼ�¼����ɹ���");
            } else {
                // �������ʧ�ܣ���ʾ�û�
                JOptionPane.showMessageDialog(null, "���ڼ�¼����ʧ�ܣ�������");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "���ݿ��������");
        } finally {
            // �ر�ResultSet��Statement��Connection
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public String queryDatabase(String studentID) {
        Connection connection = null;
        PreparedStatement statement = null; 	
        ResultSet resultSet = null;
 
        StringBuilder result = new StringBuilder();
 
        try {
            // �������ݿ�����
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
 
            // ����SQL���
            String sql = "SELECT * FROM attendance_records WHERE student_id = ?";
            statement = connection.prepareStatement(sql);
 
            // ����SQL������
            statement.setString(1, studentID);
 
            // ִ�в�ѯ
            resultSet = statement.executeQuery();
 
            // ������ѯ���
            while (resultSet.next()) {
                String date = resultSet.getString("date");
                String lesson = resultSet.getString("lesson");
                String course = resultSet.getString("course");
                String Type = resultSet.getString("type");
 
                result.append("Student ID: ").append(studentID).append("\n");
                result.append("��������: ").append(date).append("\n");
                result.append("���ڿ�ʱ: ").append(lesson).append("\n");
                result.append("����ѧ��: ").append(course).append("\n");
                result.append("��������: ").append(Type).append("\n\n");
            }
            return result.toString();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            // �ر�ResultSet��Statement��Connection
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
 
        return result.toString();
    }
    public static boolean updateDatabase(String studentName, String studentID, String date, String lesson, String course, String absenceType) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // �������ݿ�����
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

            // ���ȼ��ѧ��ID�Ƿ����
            String checkSql = "SELECT * FROM attendance_records WHERE student_id = ? AND date=? AND course=? AND student_name=?";
            statement = connection.prepareStatement(checkSql);
            statement.setString(1, studentID);
            statement.setString(2, date);
            statement.setString(3, course);
            statement.setString(4, studentName);
            resultSet = statement.executeQuery();

            // �����ѯ���Ϊ�գ�˵����������
            if (!resultSet.next()) {
                return false; // ѧ��ID�����ڣ�����false
            }

            // ���ѧ��ID���ڣ�ִ�и��²���
            String sql = "UPDATE attendance_records SET  lesson = ?,  type = ? WHERE student_id = ? AND date = ? AND course = ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, lesson);
            statement.setString(2, absenceType);
            statement.setString(3, studentID);
            statement.setString(4, date);
            statement.setString(5, course);

        
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0; // ���ظ��µ������Ƿ����0
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // ���ݿ�������󣬷���false
        } finally {
            // �ر���Դ
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}