import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Teacher extends JFrame {
	private JTable table;
    private JScrollPane scrollPane;
    private JSlider slider;
    private Connection connection;
    private String id;

    public Teacher(String id, JFrame parent) {
        this.id = id;
        setTitle("����ϵͳ");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600); // ���ӿ�������Ӧ�µĲ���
        initDatabaseConnection();
        initComponents();
    }

    private void initComponents() {
       
        scrollPane = new JScrollPane(table);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        // ��ʼ������
        initSlider();

        // ��ʼ����ť
        JButton viewPersonalInfo = new JButton("�鿴������Ϣ");
        JButton modifyPassword = new JButton("�޸ĸ�������");
        JButton backButton = new JButton("���˵���¼����"); 
        JPanel buttonPanel = new JPanel(new GridLayout(0, 1));
        buttonPanel.add(viewPersonalInfo);
        buttonPanel.add(modifyPassword);
        buttonPanel.add(backButton); // �����˰�ť���ӵ����

        // ��ʼ��ѡ����
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("¼�뿼�ڼ�¼", new InputPanel());
        tabbedPane.addTab("�޸Ŀ��ڼ�¼", new UpdatePanel());
        tabbedPane.addTab("��ѯ���ڼ�¼", new QueryPanel());
        tabbedPane.addTab("ͳ�ƿ��ڼ�¼", new StatisticsPanel());

        // �����ָ����
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, buttonPanel, scrollPane);
        splitPane.setDividerLocation(200);

        // ���ָ�����ѡ�������
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(tabbedPane, BorderLayout.CENTER);

        // ��������岢���ò���
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(splitPane, BorderLayout.CENTER);
        mainPanel.add(rightPanel, BorderLayout.EAST); // ��ѡ�������ӵ��Ҳ�

        // ��������嵽����
        getContentPane().add(mainPanel);

        // �����¼�������
        viewPersonalInfo.addActionListener(e -> viewPersonalInfo());
        modifyPassword.addActionListener(e -> modifyPassword());
        backButton.addActionListener(e -> goBack()); // Ϊ���˰�ť�����¼�������

        // ��ʾ����
        setVisible(true);
    }

    private void initSlider() {
        slider = new JSlider(JSlider.VERTICAL, 0, 100, 0);
        slider.setMajorTickSpacing(25);
        slider.setMinorTickSpacing(5);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.addChangeListener(e -> {
            int value = slider.getValue();
            int maximum = scrollPane.getVerticalScrollBar().getMaximum();
            int extent = scrollPane.getVerticalScrollBar().getVisibleAmount();
            int newPosition = (maximum * value) / 100;
            scrollPane.getVerticalScrollBar().setValue(newPosition);
        });
    }
    private void initDatabaseConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/student?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
            String user = "root";
            String password = "kzr13883288366";
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    private void viewPersonalInfo() {
        try {
            String sql = "SELECT * FROM teacher_users WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String name = resultSet.getString("name");
                String major = resultSet.getString("major");
                String degree = resultSet.getString("degree");
                JOptionPane.showMessageDialog(this, "����: " + name + "\n" +
                        "רҵ: " + major + "\n" +
                        "ѧλ: " + degree);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void modifyPassword() {
        // ����һ������������������������������
        JPanel passwordPanel = new JPanel(new GridLayout(2, 2));
        JLabel oldPasswordLabel = new JLabel("������:");
        JPasswordField oldPasswordField = new JPasswordField(15);
        JLabel newPasswordLabel = new JLabel("������:");
        JPasswordField newPasswordField = new JPasswordField(15);

        passwordPanel.add(oldPasswordLabel);
        passwordPanel.add(oldPasswordField);
        passwordPanel.add(newPasswordLabel);
        passwordPanel.add(newPasswordField);

        // ��ʾ�Ի��򲢻�ȡ�û���Ӧ
        int option = JOptionPane.showConfirmDialog(null, passwordPanel, "�޸�����", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String oldPassword = new String(oldPasswordField.getPassword());
            if (oldPassword.isEmpty()) {
                JOptionPane.showMessageDialog(this, "�����벻��Ϊ��");
                return;
            }

            try {
                String sql = "SELECT * FROM teacher_users WHERE id = ? AND password = ?";
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.setString(1, id);
                statement.setString(2, oldPassword);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    String newPassword = new String(newPasswordField.getPassword());
                    if (!newPassword.isEmpty()) {
                        sql = "UPDATE teacher_users SET password = ? WHERE id = ?";
                        statement = connection.prepareStatement(sql);
                        statement.setString(1, newPassword);
                        statement.setString(2, id);
                        int updated = statement.executeUpdate();
                        if (updated > 0) {
                            JOptionPane.showMessageDialog(this, "�����޸ĳɹ���");
                        } else {
                            JOptionPane.showMessageDialog(this, "�����޸�ʧ�ܣ�");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "�����벻��Ϊ�գ�");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "���������");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "���ݿ��������");
            }
        }
    }
    private void goBack() {
        this.setVisible(false); // ���ص�ǰ����
        new Login(); // �򿪵�¼����
    }
}