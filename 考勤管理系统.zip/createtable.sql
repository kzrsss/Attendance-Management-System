CREATE TABLE attendance_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(100),
    student_id VARCHAR(20),
    date DATE,
    lesson VARCHAR(50),
    course VARCHAR(50),
    type VARCHAR(50)
);
CREATE TABLE student_users (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(25) NOT NULL,
    password VARCHAR(20),
    major VARCHAR(25),
    class VARCHAR(25),
    PRIMARY KEY (id)
);
CREATE TABLE teacher_users (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(25) NOT NULL,
    password VARCHAR(25) NOT NULL,
    major VARCHAR(25) NOT NULL,
    degree VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);